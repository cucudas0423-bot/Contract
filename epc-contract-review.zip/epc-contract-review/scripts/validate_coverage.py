#!/usr/bin/env python3
"""Prove that every extracted redline hunk is mapped to a reviewed issue."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_id(value: Any) -> int | str:
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int):
        return value
    text = str(value).strip()
    return int(text) if text.isdigit() else text


def extract_hunk_ids(redlines: Any) -> set[int | str]:
    if not isinstance(redlines, dict) or not isinstance(redlines.get("hunks"), list):
        raise ValueError("redlines JSON must contain a hunks array")
    result: set[int | str] = set()
    for index, hunk in enumerate(redlines["hunks"]):
        if not isinstance(hunk, dict) or "hunk_id" not in hunk:
            raise ValueError(f"hunks[{index}] has no hunk_id")
        hunk_id = normalize_id(hunk["hunk_id"])
        if hunk_id in result:
            raise ValueError(f"duplicate hunk_id in redlines: {hunk_id}")
        result.add(hunk_id)
    return result


def issue_list(issues: Any) -> list[Any]:
    if isinstance(issues, list):
        return issues
    if isinstance(issues, dict) and isinstance(issues.get("issues"), list):
        return issues["issues"]
    raise ValueError("issues JSON must be an array or contain an issues array")


def covered_hunk_ids(issues: Any) -> tuple[set[int | str], list[str]]:
    covered: set[int | str] = set()
    errors: list[str] = []
    for index, issue in enumerate(issue_list(issues)):
        if not isinstance(issue, dict):
            errors.append(f"issues[{index}] is not an object")
            continue
        ids = issue.get("hunk_ids")
        if not isinstance(ids, list) or not ids:
            errors.append(f"issues[{index}] has no non-empty hunk_ids array")
            continue
        for value in ids:
            covered.add(normalize_id(value))
    return covered, errors


def sort_key(value: int | str) -> tuple[int, Any]:
    return (0, value) if isinstance(value, int) else (1, str(value))


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 2:
        print("usage: validate_coverage.py <redlines.json> <issues.json>", file=sys.stderr)
        return 2

    redline_path, issue_path = map(Path, args)
    try:
        all_hunks = extract_hunk_ids(load_json(redline_path))
        covered, structural_errors = covered_hunk_ids(load_json(issue_path))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    missing = sorted(all_hunks - covered, key=sort_key)
    unknown = sorted(covered - all_hunks, key=sort_key)

    print(f"추출된 hunk: {len(all_hunks)}")
    print(f"매핑된 hunk: {len(all_hunks & covered)}")
    print(f"누락 hunk: {len(missing)}")
    if missing:
        print("누락 목록: " + ", ".join(map(str, missing)))
    if unknown:
        print("존재하지 않는 참조: " + ", ".join(map(str, unknown)))
    for error in structural_errors:
        print("구조 오류: " + error)

    if missing or unknown or structural_errors:
        print("\n커버리지 검증 실패 — 대시보드를 생성하지 마십시오.", file=sys.stderr)
        return 1

    print("\n커버리지 검증 통과 — 모든 레드라인 hunk가 이슈에 매핑되었습니다.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
