#!/usr/bin/env python3
"""Extract tracked changes and comments from a Word contract in document order.

The output is intentionally judgment-free.  It provides stable paragraph-level
``hunk_id`` values so the reviewing model can analyse every change and later
prove coverage with ``validate_coverage.py``.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree as ET

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W_NS}


def qn(name: str) -> str:
    prefix, local = name.split(":", 1)
    if prefix != "w":
        raise ValueError(f"Unsupported namespace prefix: {prefix}")
    return f"{{{W_NS}}}{local}"


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def attr(element: ET.Element, name: str, default: str = "") -> str:
    return element.get(qn(name), default)


def read_part(docx: zipfile.ZipFile, member: str) -> ET.Element | None:
    try:
        data = docx.read(member)
    except KeyError:
        return None
    return ET.fromstring(data)


def load_document(path: Path) -> tuple[ET.Element, ET.Element | None, ET.Element | None]:
    if path.suffix.lower() != ".docx":
        raise ValueError("Input must be a .docx file")
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        with zipfile.ZipFile(path) as docx:
            document = read_part(docx, "word/document.xml")
            comments = read_part(docx, "word/comments.xml")
            styles = read_part(docx, "word/styles.xml")
    except zipfile.BadZipFile as exc:
        raise ValueError(f"Not a valid DOCX package: {path}") from exc
    if document is None:
        raise ValueError("DOCX has no word/document.xml")
    return document, comments, styles


def style_names(styles_xml: ET.Element | None) -> dict[str, str]:
    mapping: dict[str, str] = {}
    if styles_xml is None:
        return mapping
    for style in styles_xml.findall(".//w:style", NS):
        style_id = attr(style, "w:styleId")
        name = style.find("w:name", NS)
        if style_id and name is not None:
            mapping[style_id] = attr(name, "w:val").strip()
    return mapping


def parse_comments(comments_xml: ET.Element | None) -> dict[str, dict[str, str]]:
    comments: dict[str, dict[str, str]] = {}
    if comments_xml is None:
        return comments
    for comment in comments_xml.findall(".//w:comment", NS):
        comment_id = attr(comment, "w:id")
        if not comment_id:
            continue
        chunks: list[str] = []
        for node in comment.iter():
            kind = local_name(node.tag)
            if kind in {"t", "delText"} and node.text:
                chunks.append(node.text)
            elif kind == "tab":
                chunks.append("\t")
            elif kind in {"br", "cr"}:
                chunks.append("\n")
        comments[comment_id] = {
            "author": attr(comment, "w:author"),
            "initials": attr(comment, "w:initials"),
            "date": attr(comment, "w:date"),
            "text": "".join(chunks).strip(),
        }
    return comments


def parse_author_map(raw: str | None) -> dict[str, str]:
    mapping: dict[str, str] = {}
    if not raw:
        return mapping
    for item in raw.split(","):
        if not item.strip():
            continue
        if "=" not in item:
            raise ValueError("--author-map must use name=role,name=role syntax")
        name, role = item.split("=", 1)
        mapping[name.strip()] = role.strip()
    return mapping


def node_text(run: ET.Element) -> str:
    chunks: list[str] = []
    for node in run.iter():
        kind = local_name(node.tag)
        if kind in {"t", "delText"} and node.text:
            chunks.append(node.text)
        elif kind == "tab":
            chunks.append("\t")
        elif kind in {"br", "cr"}:
            chunks.append("\n")
        elif kind == "noBreakHyphen":
            chunks.append("-")
    return "".join(chunks)


def merge_run(runs: list[dict[str, str]], kind: str, text: str) -> None:
    if not text:
        return
    if runs and runs[-1]["kind"] == kind:
        runs[-1]["text"] += text
    else:
        runs.append({"kind": kind, "text": text})


def walk_content(
    node: ET.Element,
    runs: list[dict[str, str]],
    authors: set[str],
    inherited_kind: str = "normal",
) -> None:
    """Walk paragraph content while preserving normal/insert/delete order."""
    name = local_name(node.tag)

    if name in {"ins", "del"}:
        kind = name
        author = attr(node, "w:author")
        if author:
            authors.add(author)
        for child in node:
            walk_content(child, runs, authors, kind)
        return

    if name == "r":
        merge_run(runs, inherited_kind, node_text(node))
        return

    if name in {"pPr", "rPr", "sectPr", "bookmarkStart", "bookmarkEnd"}:
        return

    for child in node:
        walk_content(child, runs, authors, inherited_kind)


def paragraph_runs(paragraph: ET.Element) -> tuple[list[dict[str, str]], set[str]]:
    runs: list[dict[str, str]] = []
    authors: set[str] = set()
    for child in paragraph:
        walk_content(child, runs, authors)
    return runs, authors


def paragraph_comment_ids(paragraph: ET.Element) -> list[str]:
    ids: set[str] = set()
    for node in paragraph.iter():
        if local_name(node.tag) in {"commentRangeStart", "commentRangeEnd", "commentReference"}:
            value = attr(node, "w:id")
            if value:
                ids.add(value)
    return sorted(ids, key=lambda value: int(value) if value.isdigit() else value)


HEADING_RE = re.compile(r"(?:heading|제목)\s*([1-9])", re.IGNORECASE)


def paragraph_style(paragraph: ET.Element, styles: dict[str, str]) -> tuple[str, int | None]:
    p_style = paragraph.find("./w:pPr/w:pStyle", NS)
    style_id = attr(p_style, "w:val") if p_style is not None else ""
    style_label = styles.get(style_id, style_id)
    match = HEADING_RE.search(style_label) or HEADING_RE.search(style_id)
    return style_label, int(match.group(1)) if match else None


def visible_text(runs: Iterable[dict[str, str]], include: set[str]) -> str:
    return "".join(run["text"] for run in runs if run["kind"] in include).strip()


def extract(path: Path, author_map: dict[str, str] | None = None) -> dict[str, Any]:
    document, comments_xml, styles_xml = load_document(path)
    styles = style_names(styles_xml)
    comments = parse_comments(comments_xml)
    author_map = author_map or {}

    paragraphs = list(document.iter(qn("w:p")))
    headings: dict[int, str] = {}
    hunks: list[dict[str, Any]] = []
    author_counts: Counter[str] = Counter()

    for para_index, paragraph in enumerate(paragraphs, start=1):
        runs, authors = paragraph_runs(paragraph)
        style_name, heading_level = paragraph_style(paragraph, styles)
        comment_ids = paragraph_comment_ids(paragraph)

        for comment_id in comment_ids:
            author = comments.get(comment_id, {}).get("author", "")
            if author:
                authors.add(author)

        before_text = visible_text(runs, {"normal", "del"})
        after_text = visible_text(runs, {"normal", "ins"})
        current_text = after_text or before_text

        changed = any(run["kind"] in {"ins", "del"} and run["text"] for run in runs)
        changed = changed or bool(comment_ids)

        if changed:
            context_parts = [headings[level] for level in sorted(headings) if headings[level]]
            inserted = [run["text"] for run in runs if run["kind"] == "ins" and run["text"]]
            deleted = [run["text"] for run in runs if run["kind"] == "del" and run["text"]]
            author_list = sorted(authors, key=str.casefold)
            author_counts.update(author_list)
            hunk_id = len(hunks) + 1
            hunks.append(
                {
                    "hunk_id": hunk_id,
                    "heading_context": " > ".join(context_parts),
                    "para_index": para_index,
                    "style": style_name,
                    "authors": author_list,
                    "author_roles": {name: author_map.get(name, "") for name in author_list},
                    "before_text": before_text,
                    "after_text": after_text,
                    "inserted_spans": inserted,
                    "deleted_spans": deleted,
                    "comment_ids": comment_ids,
                    "runs": runs,
                }
            )

        if heading_level is not None and current_text:
            headings[heading_level] = current_text
            for level in list(headings):
                if level > heading_level:
                    del headings[level]

    meta = {
        "source_file": path.name,
        "total_paragraphs": len(paragraphs),
        "changed_paragraphs": len(hunks),
        "authors": dict(sorted(author_counts.items(), key=lambda item: item[0].casefold())),
    }
    return {"meta": meta, "hunks": hunks, "comments": comments}


def print_summary(result: dict[str, Any]) -> None:
    meta = result["meta"]
    print(f"File: {meta['source_file']}")
    print(f"Paragraphs: {meta['total_paragraphs']}")
    print(f"Changed paragraphs (hunks): {meta['changed_paragraphs']}")
    authors = meta.get("authors", {})
    print("Authors: " + (", ".join(f"{name} ({count})" for name, count in authors.items()) or "none"))
    for hunk in result["hunks"][:20]:
        context = hunk["heading_context"] or "(no heading)"
        print(f"\n#{hunk['hunk_id']} {context}")
        if hunk["deleted_spans"]:
            print("  - " + " | ".join(hunk["deleted_spans"])[:240])
        if hunk["inserted_spans"]:
            print("  + " + " | ".join(hunk["inserted_spans"])[:240])
        if hunk["comment_ids"]:
            print("  comments: " + ", ".join(hunk["comment_ids"]))
    remaining = len(result["hunks"]) - 20
    if remaining > 0:
        print(f"\n... and {remaining} more hunks (use --json for complete output)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", type=Path, help="Word .docx contract")
    parser.add_argument(
        "--author-map",
        help='Optional mapping, e.g. "Megan Sprot=Contractor,samsung=Owner"',
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--json", action="store_true", help="Print complete JSON")
    group.add_argument("--summary", action="store_true", help="Print human-readable statistics")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = extract(args.file, parse_author_map(args.author_map))
    except (OSError, ValueError, ET.ParseError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_summary(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
