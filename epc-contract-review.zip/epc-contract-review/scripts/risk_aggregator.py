#!/usr/bin/env python3
"""Validate and aggregate Mode A's base 32 items plus confirmed extras."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

VALID_JUDGMENTS = ("위험없음", "경미", "중대", "판단불가")
SCORES = {"위험없음": 0, "경미": 1, "중대": 3, "판단불가": 1}
RED_FLAG_IDS = [f"RF{i}" for i in range(1, 9)]
GROUPS = {
    "A_상업조건": [1, 2, 3],
    "B_공정일정": [4, 5, 6],
    "C_성능보증": [7, 8, 9],
    "D_보험": [10, 11, 12],
    "E_IRA세제": [13, 14, 15],
    "F_계통연계": [16, 17, 18],
    "G_공급망": [19, 20, 21],
    "H_분쟁IP기밀": [22, 23, 24],
}
GENERAL_IDS = [f"G{i}" for i in range(1, 25)]


def blank_item(item_id: str) -> dict[str, Any]:
    return {
        "id": item_id,
        "clause_number": "",
        "clause_title": "",
        "status_summary": "",
        "quote": "",
        "judgment": "판단불가",
        "review_flag": True,
        "rationale": "",
        "counter_proposal": "",
    }


def schema() -> dict[str, Any]:
    return {
        "contract_meta": {
            "counterparty": "",
            "contract_type": "EPC | PPA | MSA | O&M | IA | Other",
            "governing_law": "",
            "project_state": "",
    "review_perspective": "EPC Contractor",
        },
        "review_scope": {
            "confirmed": False,
            "confirmed_additional_count": 0,
            "confirmation_note": "",
        },
        "red_flags": {item_id: blank_item(item_id) for item_id in RED_FLAG_IDS},
        "general_items": [blank_item(item_id) for item_id in GENERAL_IDS],
        "additional_items": [],
    }


def validate(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    review_scope = data.get("review_scope")
    red_flags = data.get("red_flags")
    general_items = data.get("general_items")
    additional_items = data.get("additional_items")

    if not isinstance(review_scope, dict):
        errors.append("review_scope must be an object")
        review_scope = {}
    if review_scope.get("confirmed") is not True:
        errors.append("review_scope.confirmed must be true before aggregation")
    confirmed_count = review_scope.get("confirmed_additional_count")
    if type(confirmed_count) is not int or confirmed_count < 0:
        errors.append("review_scope.confirmed_additional_count must be a non-negative integer")
        confirmed_count = 0

    if not isinstance(red_flags, dict):
        errors.append("red_flags must be an object")
        red_flags = {}
    if not isinstance(general_items, list):
        errors.append("general_items must be an array")
        general_items = []
    if not isinstance(additional_items, list):
        errors.append("additional_items must be an array")
        additional_items = []

    missing_rf = [item_id for item_id in RED_FLAG_IDS if item_id not in red_flags]
    extra_rf = sorted(set(red_flags) - set(RED_FLAG_IDS))
    if missing_rf:
        errors.append("missing Red Flag IDs: " + ", ".join(missing_rf))
    if extra_rf:
        errors.append("unknown Red Flag IDs: " + ", ".join(extra_rf))

    by_id: dict[str, Any] = {}
    for index, item in enumerate(general_items):
        if not isinstance(item, dict):
            errors.append(f"general_items[{index}] must be an object")
            continue
        item_id = str(item.get("id", ""))
        if item_id in by_id:
            errors.append(f"duplicate general item ID: {item_id}")
        by_id[item_id] = item

    missing_general = [item_id for item_id in GENERAL_IDS if item_id not in by_id]
    extra_general = sorted(set(by_id) - set(GENERAL_IDS))
    if missing_general:
        errors.append("missing general item IDs: " + ", ".join(missing_general))
    if extra_general:
        errors.append("unknown general item IDs: " + ", ".join(extra_general))

    additional_by_id: dict[str, Any] = {}
    additional_ids: list[str] = []
    for index, item in enumerate(additional_items):
        if not isinstance(item, dict):
            errors.append(f"additional_items[{index}] must be an object")
            continue
        item_id = str(item.get("id", ""))
        additional_ids.append(item_id)
        if item_id in additional_by_id:
            errors.append(f"duplicate additional item ID: {item_id}")
        additional_by_id[item_id] = item

    if confirmed_count != len(additional_items):
        errors.append(
            "confirmed additional item count does not match additional_items: "
            f"{confirmed_count} != {len(additional_items)}"
        )
    expected_additional_ids = [f"X{i}" for i in range(1, len(additional_items) + 1)]
    if additional_ids != expected_additional_ids:
        errors.append(
            "additional item IDs must be contiguous and ordered: "
            + (", ".join(expected_additional_ids) or "(none)")
        )

    all_items = list(red_flags.values()) + list(by_id.values()) + list(additional_by_id.values())
    for item in all_items:
        if not isinstance(item, dict):
            errors.append("every review item must be an object")
            continue
        item_id = str(item.get("id", "(unknown)"))
        judgment = item.get("judgment")
        if judgment not in VALID_JUDGMENTS:
            errors.append(f"{item_id}: invalid judgment {judgment!r}")
        if "review_flag" in item and not isinstance(item["review_flag"], bool):
            errors.append(f"{item_id}: review_flag must be true or false")
    return errors


def overall_rating(total_score: int, critical_count: int) -> str:
    if critical_count >= 4 or total_score >= 24:
        return "Critical"
    if critical_count >= 2 or total_score >= 18:
        return "High"
    if critical_count >= 1 or total_score >= 10:
        return "Medium"
    return "Low"


def aggregate(data: dict[str, Any]) -> dict[str, Any]:
    errors = validate(data)
    if errors:
        raise ValueError("\n".join(errors))

    red_flags = [data["red_flags"][item_id] for item_id in RED_FLAG_IDS]
    general_by_id = {str(item["id"]): item for item in data["general_items"]}
    general_items = [general_by_id[item_id] for item_id in GENERAL_IDS]
    additional_items = list(data["additional_items"])
    all_items = red_flags + general_items + additional_items

    counts = Counter(str(item["judgment"]) for item in all_items)
    red_flag_counts = Counter(str(item["judgment"]) for item in red_flags)
    additional_counts = Counter(str(item["judgment"]) for item in additional_items)
    total_score = sum(SCORES[str(item["judgment"])] for item in all_items)
    critical_count = counts["중대"]
    review_flag_count = sum(bool(item.get("review_flag")) for item in all_items)

    group_breakdown: dict[str, dict[str, Any]] = {}
    for group_name, numbers in GROUPS.items():
        items = [general_by_id[f"G{number}"] for number in numbers]
        group_counts = Counter(str(item["judgment"]) for item in items)
        group_breakdown[group_name] = {
            "ids": [f"G{number}" for number in numbers],
            "counts": {key: group_counts.get(key, 0) for key in VALID_JUDGMENTS},
            "score": sum(SCORES[str(item["judgment"])] for item in items),
        }
    if additional_items:
        group_breakdown["I_계약특화"] = {
            "ids": [str(item["id"]) for item in additional_items],
            "counts": {key: additional_counts.get(key, 0) for key in VALID_JUDGMENTS},
            "score": sum(SCORES[str(item["judgment"])] for item in additional_items),
        }

    return {
        "contract_meta": data.get("contract_meta", {}),
        "review_scope": data["review_scope"],
        "counts": {key: counts.get(key, 0) for key in VALID_JUDGMENTS},
        "red_flag_counts": {key: red_flag_counts.get(key, 0) for key in VALID_JUDGMENTS},
        "additional_counts": {key: additional_counts.get(key, 0) for key in VALID_JUDGMENTS},
        "base_total_items": 32,
        "additional_total_items": len(additional_items),
        "total_items": len(all_items),
        "group_breakdown": group_breakdown,
        "scores": {
            "red_flag_score": sum(SCORES[str(item["judgment"])] for item in red_flags),
            "general_score": sum(SCORES[str(item["judgment"])] for item in general_items),
            "additional_score": sum(SCORES[str(item["judgment"])] for item in additional_items),
            "total_score": total_score,
        },
        "critical_count": critical_count,
        "review_flag_count": review_flag_count,
        "overall_rating": overall_rating(total_score, critical_count),
        "validation": f"32/32 기본항목 + {len(additional_items)}개 추가항목 확인됨",
    }


def print_human(result: dict[str, Any]) -> None:
    meta = result.get("contract_meta", {})
    print(f"계약상대방: {meta.get('counterparty', '-')}")
    print(f"계약유형: {meta.get('contract_type', '-')}")
    print(f"검토범위: 기본 32개 + 추가 {result['additional_total_items']}개 (사용자 확정)")
    print(f"종합 등급: {result['overall_rating']}")
    print(f"총점: {result['scores']['total_score']}")
    print(f"중대: {result['critical_count']} / 검토필요: {result['review_flag_count']}")
    counts = result["counts"]
    print("판정: " + ", ".join(f"{key} {counts[key]}" for key in VALID_JUDGMENTS))
    print("\n그룹별")
    for group, details in result["group_breakdown"].items():
        print(f"- {group}: score={details['score']}, 중대={details['counts']['중대']}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path, help="base 32 + confirmed-extra review JSON")
    parser.add_argument("--schema", action="store_true", help="Print input schema")
    parser.add_argument("--json", action="store_true", help="Print aggregate result as JSON")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.schema:
        print(json.dumps(schema(), ensure_ascii=False, indent=2))
        return 0
    if args.input is None:
        print("error: input JSON is required unless --schema is used", file=sys.stderr)
        return 2
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        result = aggregate(data)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_human(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
