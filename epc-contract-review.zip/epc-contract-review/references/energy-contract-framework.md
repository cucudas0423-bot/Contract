# Energy contract framework

Use this reference only for U.S. solar, BESS, EPC, supply, and associated O&M agreements. Tailor every item to the agreement and transaction; a checklist item is not automatically a defect.

## Cross-cutting Owner risk areas

- Parties, authority, parent guarantees, assignment/change of control, and credit support.
- Document precedence, definitions, scope gaps, exclusions, interfaces, and change-order control.
- Price basis, allowances, escalation, taxes/tariffs, retainage, invoicing, audit rights, and payment disputes.
- Schedule baseline, relief events, notice, concurrent delay, recovery plan, milestone remedies, and termination rights.
- Insurance, indemnity, limitation of liability, waiver of consequential damages, IP indemnity, and subrogation.
- Compliance, permits, labor requirements, sanctions/export controls, environmental obligations, and records.
- Confidentiality, data rights, cybersecurity, publicity, and dispute resolution.

## EPC and construction

Check design standard and fitness-for-purpose language; site access and differing site conditions; procurement/subcontractor controls; quality and inspection; owner-furnished equipment; title/risk of loss; commissioning; punch list; substantial/final completion; warranties; performance tests; LD exclusivity; and step-in, suspension, default, and termination remedies.

Confirm that acceptance criteria, guaranteed values, test protocols, and remedies align across the EPC agreement, exhibits, equipment warranties, interconnection requirements, and offtake obligations.

## Solar and BESS

Check energy/availability guarantees, measurement methodology, exclusions, curtailment treatment, production estimates, and remedies. For BESS, address usable capacity, round-trip efficiency, degradation, augmentation, thermal management, fire detection/suppression, emergency response, controls integration, cybersecurity, warranty pass-through, recall/defect response, and end-of-life obligations.

Flag tax-credit, domestic-content, prevailing-wage/apprenticeship, transferability, and safe-harbor issues as items requiring tax or regulatory confirmation; do not promise incentive eligibility.

## Equipment purchase

Check technical specifications, approved substitutions, inspection and factory acceptance testing, delivery terms/Incoterms, title and loss transfer, packing, delay remedies, import/tariff allocation, acceptance rejection rights, warranty start and duration, repair/replacement logistics, spare parts, software/firmware and data rights, IP indemnity, and supplier insolvency or allocation risk.

Make sure the supply agreement's delivery, warranty, and remedy regime works with the EPC schedule and downstream project obligations.
