# EPC Contractor 계약 리스크 판정기준

모든 판정은 EPC Contractor 관점이다. `판단불가`는 조항 또는 핵심 첨부가 없어 EPC의 가격·일정·책임을 평가할 수 없다는 뜻이며 위험없음으로 처리하지 않는다. 경계 항목은 EPC에 불리한 쪽으로 판정하고 `[검토필요]`를 붙인다.

## Red Flag 8개

| ID | 항목 | EPC에 유리한 기준 | EPC 중대 리스크 |
|---|---|---|---|
| RF1 | Governing Law / Venue | 중립·예측 가능한 법, 공정한 venue·중재 | Owner 단독 선택권, 불명확한 법·관할 |
| RF2 | Limitation of Liability | EPC 총책임 cap, 간접손해 배제, EPC 과실에 맞는 carve-out | EPC 무제한 책임 또는 Owner 손해만 과도하게 carve-out |
| RF3 | Force Majeure | 광범위한 불가항력에 EOT·Cost·장기 종료권 | EOT만 허용, 공급망·전쟁·계통·정부행위 제외 |
| RF4 | Owner T4C | Owner 해지 시 기성·취소비용·합리적 demob/손실 보상 | Owner가 무보상 또는 모호한 비용으로 해지 |
| RF5 | 세제·인센티브 | Owner가 인센티브 요건·부지·금융 정보를 책임지고 EPC 귀책만 배상 | EPC가 통제 불가능한 credit/recapture를 무제한 부담 |
| RF6 | 공급망·강제노동 | Owner 사양·지정공급사 위험과 EPC 조달 위험을 구분 | EPC가 Owner 지정품·정책변경·통관 지연까지 부담 |
| RF7 | Indemnification | 각 당사자의 과실·위반에 비례, EPC indemnity 범위·절차 제한 | Owner의 과실·현장조건·법정 책임까지 EPC가 면책 |
| RF8 | Assignment / Change of Control | EPC 계열사·대주·보증인 구조를 위한 합리적 양도·step-in | Owner가 EPC financing/조직 변경을 임의 차단·해지 |

## 일반지표 24개

| ID | 항목 | EPC 기준 |
|---|---|---|
| G1 | Price Adjustment / Escalation | 고정가 전제와 법변경·관세·Owner 지연·지정공급사·환율 예외를 명확히 한다. |
| G2 | Change Order | 서면 지시, 가격·기간 산정, 부당 지연 시 EPC의 interim relief를 둔다. |
| G3 | Payment | 객관적 milestone, 신속 지급, 이자·중지·해지권, Owner 신용보강을 확인한다. |
| G4 | Completion | EPC 통제 범위의 객관적 시험·인수기준과 deemed acceptance를 둔다. |
| G5 | Delay LDs | 합리적 상한, sole remedy, Owner/TSO 지연 EOT와 연동한다. |
| G6 | EOT | Owner·TSO·정부·현장·공급망·법변경에 시간 및 비용 구제를 확인한다. |
| G7 | Performance tests | 기준조건·보정·재시험·독립검증·Owner 협력의무를 명확히 한다. |
| G8 | Degradation | EPC 보증과 OEM 장기보증·운영조건·검증 방법을 구분한다. |
| G9 | Availability | O&M 기간·제외시간·Owner/TSO 제약·LD cap을 확인한다. |
| G10 | CAR | 보험 위험·deductible·testing 기간을 EPC 가격과 일치시킨다. |
| G11 | Additional insured | Owner/lender 추가피보험은 EPC 보험·계약상 역할과 일치해야 한다. |
| G12 | Insurance limits | 한도·보험료·자기부담·보험금 지연 위험을 EPC가 비합리적으로 부담하지 않게 한다. |
| G13 | Domestic Content | 실제 적용 시 Owner가 사양·인증·기준변경 책임을 지고 EPC 자료제출 범위를 정한다. |
| G14 | PWA | 실제 적용 시 Owner 현장정보와 EPC/subcontractor flow-down 책임을 구분한다. |
| G15 | Safe Harbor | 실제 적용 시 Owner가 요구 요건·일정·증빙을 명확히 제공한다. |
| G16 | Interconnection | TSO study, upgrade, 조건변경, 접속 지연과 비용·기간을 EPC risk에서 분리한다. |
| G17 | Curtailment | EPC 성능보증에서 grid/Owner dispatch·curtailment를 제외한다. |
| G18 | Network upgrades | Owner/TSO upgrade 범위·비용·선행조건·EOT를 명확히 한다. |
| G19 | Module traceability | EPC 자료제출 의무와 Owner 지정공급사·정책 위험을 구분한다. |
| G20 | Tariffs | 관세·수입규제·제재의 Base Date 이후 변동을 Change로 처리한다. |
| G21 | Alternative supplier | Owner 지정 또는 OEM failure 시 EPC의 대체조달·가격·기간 권리를 둔다. |
| G22 | Dispute resolution | 신속한 DAB/expert 결정, 미지급금·분쟁 중 수행의 대가를 확보한다. |
| G23 | IP | EPC 배경 IP를 보호하고 Owner license는 프로젝트 사용 범위로 한정한다. |
| G24 | Confidentiality / data | EPC 영업비밀·소프트웨어·현장 데이터 접근과 사이버 책임을 균형화한다. |

FIDIC 2017 Silver Book, AIA 및 현지 EPC 관행은 비교축이다. 실제 준거법·프로젝트 소재지 법령·강행규정이 우선한다.
