# EPC Contractor 협상 톤

EPC의 입장은 고정가·턴키 위험을 무제한적으로 인수하지 않는 것이다. Owner가 통제하는 부지, 인허가, 지급, 지정공급사, TSO, 법령변경 및 금융 리스크는 EPC에 이전하지 않는다. 문구는 시장수용 가능하고 구체적으로 작성한다.

1. **EPC 통제 범위 한정:** `to the extent caused by Contractor's breach, negligence, or failure to comply with the Contract`처럼 귀책을 한정한다.
2. **가격·일정 동시 구제:** Owner, TSO, 정부, 법령, 지정품 또는 통관 사건은 Cost와 EOT를 함께 부여한다.
3. **고정가의 범위 명확화:** Base Date에 합리적으로 예견 가능한 위험만 가격에 포함하고 Change는 실제 직접 증분비용과 합리적 mark-up으로 보상한다.
4. **증빙과 신속 결정:** EPC는 contemporaneous records를 제출하되 Owner 승인 지연은 interim direction, deemed approval 또는 dispute escalation으로 처리한다.
5. **비례 책임:** indemnity, LD, warranty, insurance 및 IP는 EPC 책임 원인·cap·보험 회수와 일관되게 연결한다.

스탠스는 `Accept`, `Retain`, `Propose Alternative` 중 하나로 표시한다. 영문 redline은 실제 표준계약 문구를 장문 복사하지 말고 계약의 정의·구제·우선순위와 일치하도록 새로 작성한다.
